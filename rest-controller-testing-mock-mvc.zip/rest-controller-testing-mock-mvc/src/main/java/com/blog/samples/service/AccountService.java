package com.blog.samples.service;

import org.springframework.stereotype.Service;

import com.blog.samples.model.Account;
@Service
public interface AccountService {
	
	public Account loadAccount(Long accountId);
	
	public Long createAccount(Account account);	
}