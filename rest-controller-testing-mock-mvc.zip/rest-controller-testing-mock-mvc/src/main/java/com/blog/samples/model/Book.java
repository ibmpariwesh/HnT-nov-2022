package com.blog.samples.model;

import lombok.Data;

@Data
public class Book {
	private String title;
}
