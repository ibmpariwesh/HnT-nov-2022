package com.blog.samples.service;

import org.springframework.stereotype.Service;

import com.blog.samples.model.Account;
@Service
public class AccountServiceImpl implements AccountService {

	@Override
	public Account loadAccount(Long accountId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Long createAccount(Account account) {
		// TODO Auto-generated method stub
		return null;
	}

}
