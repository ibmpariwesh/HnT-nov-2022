package com.blog.samples.service;

import com.blog.samples.model.Book;

public interface BookService {
	String save(Book book);
}
