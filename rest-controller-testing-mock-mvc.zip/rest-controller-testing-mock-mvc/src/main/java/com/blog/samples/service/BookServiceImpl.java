package com.blog.samples.service;

import org.springframework.stereotype.Service;

import com.blog.samples.model.Book;
@Service
public class BookServiceImpl implements BookService{
	
	public String save(Book book) {
		return "3444";
	}
}
