package com.blog.samples.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.blog.samples.model.Book;
import com.blog.samples.service.BookService;

@RestController
public class BookController {
	@Autowired
	BookService bookService;
	@PostMapping("/api/book")
	@ResponseStatus(code = HttpStatus.CREATED)
	public String saveBook(@RequestBody Book book) {
		return bookService.save(book);
	}
}
