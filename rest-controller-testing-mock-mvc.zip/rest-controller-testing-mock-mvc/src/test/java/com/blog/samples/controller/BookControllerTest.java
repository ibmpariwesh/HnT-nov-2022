package com.blog.samples.controller;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.setup.MockMvcBuilders.webAppContextSetup;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.web.context.WebApplicationContext;

import com.blog.samples.Application;
import com.blog.samples.model.Book;
import com.blog.samples.service.BookService;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = WebEnvironment.MOCK, classes = { Application.class })
public class BookControllerTest {
	private MockMvc mockMvc;
	@MockBean
	private BookService bookServiceMock;
	@Autowired
	private WebApplicationContext webApplicationContext;

	@Before
	public void setUp() {
		this.mockMvc = webAppContextSetup(webApplicationContext).build();
	}

	@Test
	public void testSaveBook() throws Exception {
		when(bookServiceMock.save(any(Book.class))).thenReturn("123");
		mockMvc.perform(post("/api/book").contentType(MediaType.APPLICATION_JSON)
				.content("{\"title\":\"Learn Java\"}")).
				andExpect(status().isCreated())
				.andExpect(content().string("123"));
	}

}
